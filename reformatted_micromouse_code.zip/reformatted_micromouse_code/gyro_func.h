

void setup_gyro(){
  Serial.begin(9600);
  Wire.begin();

  if (!gyro.init())
  {
    Serial.println("Failed to autodetect gyro type!");
    while (1);
  }

  gyro.enableDefault();
}




void read_angle(){
  gyro.read();
  gyro_raw_data = ((int)gyro.g.z);
  gyro_dps = (gyro_raw_data * gyro_raw_dps_conversion_factor) / 1000;
 
  
  
  //Serial.print("G ");
  //Serial.print("X: ");
  //Serial.print((int)gyro.g.x);
  //Serial.print(" Y: ");
  //Serial.print((int)gyro.g.y);
  Serial.print("gyro Reading");
  Serial.print(" Z Raw Data: ");
  Serial.println(gyro_raw_data);
  Serial.println(" Z dps: ");
  
  delay(100);
}
//*/
